<?php

namespace Drupal\pfizer_custom_pages\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\taxonomy\Entity\Term;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class PfizerPublicationCornerForm.
 */
class PfizerPublicationCornerForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'pfizer_publication_corner_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $keyword_url = base64_decode(\Drupal::request()->get('keyword'));

    if (!empty($keyword_url)) {

      $form['publication_keyword'] = [
        '#title' => 'Keyword',
        '#type' => 'textfield',
        '#description' => 'Keyword',
        '#default_value' => $keyword_url,
        '#attributes' => [
          'placeholder' => t('Keyword'),
        ],
      ];

    }
    else {

      $form['publication_keyword'] = [
        '#title' => 'Keyword',
        '#type' => 'textfield',
        '#description' => 'Keyword',
        '#attributes' => [
          'placeholder' => t('Keyword'),
        ],
      ];

    }

    $congress_type_url = base64_decode(\Drupal::request()->get('congress_type'));

    $form['publication_journal'] = [
      '#title' => 'Congress Type',
      '#type' => 'select',
      '#description' => 'Congress Type',
      '#default_value' => $congress_type_url,
      '#options' => [
        '' => 'Congress',
        '61' => 'AAFP 2020',
        '66' => 'AAHKS 2020',
        '71' => 'AAPM&R 2020',
        '146' => 'ACR 2017',
        '141' => 'ACR 2018',
        '106' => 'ACR 2019',
        '76' => 'ACR 2020',
        '21' => 'ACR 2021',
        '46' => 'ACT 2021',
        '41' => 'ANA 2020',
        '81' => 'ASRA 2020',
        '56' => 'ASRA 2021',
        '151' => 'EFIC 2017',
        '111' => 'EFIC 2019',
        '116' => 'EULAR 2019',
        '26' => 'EULAR 2020',
        '86' => 'ISPE 2020',
        '121' => 'ISPOR-EU 2019',
        '91' => 'ISPOR-EU 2020',
        '31' => 'JOA 2020',
        '126' => 'OARSI 2019',
        '96' => 'OMED 2020',
        '51' => 'PAINWEEK 2020',
        '101' => 'SGIM 2020',
      ],
    ];

    $year_category_page_query = \Drupal::entityQuery('taxonomy_term')
      ->condition('status', 1, '=')
      ->condition('vid', 'journal_year');
    $year_category_page_query_execute = $year_category_page_query->execute();

    foreach ($year_category_page_query_execute as $year_category_value) {
      $year_term_load = Term::load($year_category_value);
      $year_name = $year_term_load->getName();
      $year_list[$year_category_value] = $year_name;
      $year_tid[] = $year_category_value;
    }
    // $emptyArray = ' --Select Year-- ';
    // $new_array = [$emptyArray, $year_list];.
    $year_url = base64_decode(\Drupal::request()->get('year'));

    if (!empty($year_url)) {

      $form['publication_year'] = [
        '#title' => 'Year',
        '#type' => 'select',
        '#description' => 'Year',
        '#default_value' => $year_url,
        '#options' => [
          '' => 'Year',
          '156' => '2021',
          '16' => '2020',
          '6' => '2019',
          '131' => '2018',
          '136' => '2017',
        ],
      ];

    }
    else {

      $form['publication_year'] = [
        '#title' => 'Year',
        '#type' => 'select',
        '#description' => 'Year',
        '#default_value' => $year_url,
        '#options' => [
          '' => 'Year',
          '156' => '2021',
          '16' => '2020',
          '6' => '2019',
          '131' => '2018',
          '136' => '2017',
        ],
      ];

    }

    $author_url = base64_decode(\Drupal::request()->get('author'));

    if (!empty($author_url)) {

      $form['publication_author'] = [
        '#title' => 'Author',
        '#type' => 'textfield',
        '#description' => 'Author',
        '#default_value' => $author_url,
        '#attributes' => [
          'placeholder' => t('Author'),
        ],
      ];

    }
    else {

      $form['publication_author'] = [
        '#title' => 'Author',
        '#type' => 'textfield',
        '#description' => 'Author',
        '#attributes' => [
          'placeholder' => t('Author'),
        ],
      ];

    }

    $journal_category_page_query = \Drupal::entityQuery('taxonomy_term')
      ->condition('status', 1, '=')
      ->condition('vid', 'journal_category');
    $journal_category_page_query_execute = $journal_category_page_query->execute();

    foreach ($journal_category_page_query_execute as $journal_category_value) {
      $journal_term_load = Term::load($journal_category_value);
      $journal_name = $journal_term_load->getName();
      $journal_list[$journal_category_value] = $journal_name;
      $journal_tid[] = $journal_category_value;
    }
    // $emptyArray_journal = ' --Select Journal-- ';
    // $new_array_journal = [$emptyArray_journal, $journal_list];.
    $journal_url = base64_decode(\Drupal::request()->get('journal'));

    if (!empty($journal_url)) {

      $form['congress_type'] = [
        '#title' => 'Journal',
        '#type' => 'select',
        '#description' => 'Journal',
        '#default_value' => $journal_url,
        '#options' => [
          '' => 'Journal',
          '161' => 'JAMA - Journal of the American Medical Association',
          '166' => 'Annals of the Rheumatic Diseases',
          '176' => 'Pain 2019',
          '171' => 'Pain 2020',
          '181' => 'Seminars in Arthritis and Rheumatism',
          '186' => 'Journal of Pain Research',
          '191' => 'Osteoarthritis and Cartilage',
        ],
      ];

    }
    else {

      $form['congress_type'] = [
        '#title' => 'Journal',
        '#type' => 'select',
        '#description' => 'Journal',
        '#default_value' => $publication_type_url,
        '#options' => [
          '' => 'Journal',
          '161' => 'JAMA - Journal of the American Medical Association',
          '166' => 'Annals of the Rheumatic Diseases',
          '176' => 'Pain 2019',
          '171' => 'Pain 2020',
          '181' => 'Seminars in Arthritis and Rheumatism',
          '186' => 'Journal of Pain Research',
          '191' => 'Osteoarthritis and Cartilage',
        ],
      ];

    }

    $publication_type_url = base64_decode(\Drupal::request()->get('publication_type'));

    if (!empty($publication_type_url)) {

      $form['publication_type'] = [
        '#title' => 'Publication Type',
        '#type' => 'select',
        '#description' => 'Publication Type',
        '#default_value' => $publication_type_url,
        '#options' => [
          '' => 'Publication Type',
          'primary_manuscript' => 'Primary Manuscript',
          'secondary_manuscript' => 'Secondary Manuscript',
          'review_article' => 'Review Article',
          'meta_analysis' => 'Meta Analysis',
          'oral_presentation' => 'Oral Presentation',
          'poster' => 'Poster',
          'other' => 'Other',
        ],
      ];

    }
    else {

      $form['publication_type'] = [
        '#title' => 'Publication Type',
        '#type' => 'select',
        '#description' => 'Publication Type',
        '#default_value' => 'select_option',
        '#options' => [
          '' => 'Publication Type',
          'primary_manuscript' => 'Primary Manuscript',
          'secondary_manuscript' => 'Secondary Manuscript',
          'review_article' => 'Review Article',
          'meta_analysis' => 'Meta Analysis',
          'oral_presentation' => 'Oral Presentation',
          'poster' => 'Poster',
          'other' => 'Other',
        ],
      ];

    }

    $article_type = base64_decode(\Drupal::request()->get('article_type'));

    if (!empty($article_type)) {

      $form['article_type'] = [
        '#title' => 'Article',
        '#type' => 'select',
        '#description' => 'Article',
        '#default_value' => $article_type,
        '#options' => [
          '' => 'Article Type',
          'congress_article' => 'Congress',
          'journal_article' => 'Journal',
        ],
      ];

    }
    else {

      $form['article_type'] = [
        '#title' => 'Article',
        '#type' => 'select',
        '#description' => 'Article',
        '#default_value' => $article_type,
        '#options' => [
          '' => 'Article Type',
          'congress_article' => 'Congress',
          'journal_article' => 'Journal',
        ],
      ];

    }

    $form['actions']['#type'] = 'actions';

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => 'Search',
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $publication_keyword = base64_encode($form_state->getValue('publication_keyword'));
    $publication_author = base64_encode($form_state->getValue('publication_author'));
    $publication_journal = base64_encode($form_state->getValue('congress_type'));
    $publication_congress = base64_encode($form_state->getValue('publication_journal'));
    $publication_year = base64_encode($form_state->getValue('publication_year'));
    $publication_type = base64_encode($form_state->getValue('publication_type'));
    $article_type = base64_encode($form_state->getValue('article_type'));
    global $base_url;
    $path = $base_url . '/publication-corner?keyword=' . $publication_keyword . '&author=' . $publication_author . '&journal=' . $publication_journal . '&year=' . $publication_year . '&publication_type=' . $publication_type . '&article_type=' . $article_type . '&congress_type=' . $publication_congress;
    $response = new RedirectResponse($path);
    $response->send();

  }

}
