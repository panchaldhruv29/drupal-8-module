<?php

namespace Drupal\pfizer_custom_pages\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class PfizerPublicationCornerAjaxForm.
 */
class PfizerPublicationCornerAjaxForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'pfizer_publication_corner_ajax_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $author = base64_decode(\Drupal::request()->get('author'));
    $journal = base64_decode(\Drupal::request()->get('journal'));
    $year = base64_decode(\Drupal::request()->get('year'));
    $publication_type = base64_decode(\Drupal::request()->get('publication_type'));
    $congress_type = base64_decode(\Drupal::request()->get('congress_type'));
    $publication_type_array_count = count(explode(',', $publication_type));

    if ($publication_type_array_count > 1) {
      $publication_type = explode(',', $publication_type);
    }
    else {
      $publication_type = [$publication_type];
    }

    $form['publication_type_ajax'] = [
      '#type' => 'checkboxes',
      '#options' => [
        'primary_manuscript' => 'Primary Manuscript',
        'secondary_manuscript' => 'Secondary Manuscript',
        'review_article' => 'Review Article',
        'meta_analysis' => 'Meta Analysis',
        'oral_presentation' => 'Oral Presentation',
        'poster' => 'Poster',
        'other' => 'Other',
      ],
      '#title' => $this->t('Publication Type'),
      '#default_value' => $publication_type,
      '#attributes' => [
        'class' => ['custom-publication-type-ajax'],
      ],

    ];

    $publication_congress_type_array_count = count(explode(',', $congress_type));

    if ($publication_congress_type_array_count > 1) {
      $congress_type = explode(',', $congress_type);
    }
    else {
      $congress_type = [$congress_type];
    }

    $form['publication_congress_ajax'] = [
      '#title' => 'Congress',
      '#type' => 'checkboxes',
      '#default_value' => $congress_type,
      '#options' => [
        '61' => 'AAFP 2020',
        '66' => 'AAHKS 2020',
        '71' => 'AAPM&R 2020',
        '146' => 'ACR 2017',
        '141' => 'ACR 2018',
        '106' => 'ACR 2019',
        '76' => 'ACR 2020',
        '21' => 'ACR 2021',
        '46' => 'ACT 2021',
        '41' => 'ANA 2020',
        '81' => 'ASRA 2020',
        '56' => 'ASRA 2021',
        '151' => 'EFIC 2017',
        '111' => 'EFIC 2019',
        '116' => 'EULAR 2019',
        '26' => 'EULAR 2020',
        '86' => 'ISPE 2020',
        '121' => 'ISPOR-EU 2019',
        '91' => 'ISPOR-EU 2020',
        '31' => 'JOA 2020',
        '126' => 'OARSI 2019',
        '96' => 'OMED 2020',
        '51' => 'PAINWEEK 2020',
        '101' => 'SGIM 2020',
      ],
      '#attributes' => [
        'class' => ['custom-publication-congress-type-ajax'],
      ],

    ];

    $publication_journal_array_count = count(explode(',', $journal));

    if ($publication_journal_array_count > 1) {
      $journal = explode(',', $journal);
    }
    else {
      $journal = [$journal];
    }

    $form['publication_journal_ajax'] = [
      '#title' => 'Journal',
      '#type' => 'checkboxes',
      '#default_value' => $journal,
      '#options' => [
        '161' => 'JAMA - Journal of the American Medical Association',
        '166' => 'Annals of the Rheumatic Diseases',
        '176' => 'Pain 2019',
        '171' => 'Pain 2020',
        '181' => 'Seminars in Arthritis and Rheumatism',
        '186' => 'Journal of Pain Research',
        '191' => 'Osteoarthritis and Cartilage',
      ],
      '#attributes' => [
        'class' => ['custom-publication-journal-ajax'],
      ],

    ];

    $publication_year_array_count = count(explode(',', $year));

    if ($publication_year_array_count > 1) {
      $year = explode(',', $year);
    }
    else {
      $year = [$year];
    }

    $form['publication_year_ajax'] = [
      '#title' => 'Year',
      '#type' => 'checkboxes',
      '#default_value' => $year,
      '#options' => [
        '156' => '2021',
        '16' => '2020',
        '6' => '2019',
        '131' => '2018',
        '136' => '2017',
      ],
      '#attributes' => [
        'class' => ['custom-publication-year-ajax'],
      ],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}
