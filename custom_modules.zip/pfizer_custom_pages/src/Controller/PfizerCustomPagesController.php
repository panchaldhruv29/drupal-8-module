<?php

namespace Drupal\pfizer_custom_pages\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Database\Database;
use Drupal\file\Entity\File;

/**
 * Class PfizerCustomPagesController.
 */
class PfizerCustomPagesController extends ControllerBase {

  /**
   * Custom template for authentication page.
   */
  public function authenticationPage() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $authentication_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'authentication_page', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $authentication_page_query_execute = $authentication_page_query->execute();
    foreach ($authentication_page_query_execute as $authentication_page_nids) {
      $entity_load = Node::load($authentication_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    return [
      '#theme' => 'authenticationpage',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for access denied page.
   */
  public function accessDeniedPage() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $access_denied_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'access_denied_page', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $access_denied_page_query_execute = $access_denied_page_query->execute();
    foreach ($access_denied_page_query_execute as $access_denied_page_nids) {
      $entity_load = Node::load($access_denied_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    return [
      '#theme' => 'accessdeniedpage',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for home page.
   */
  public function homePage() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $home_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'home_page', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $home_page_query_execute = $home_page_query->execute();
    foreach ($home_page_query_execute as $home_page_nids) {
      $entity_load = Node::load($home_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'homepage',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for oa progression page.
   */
  public function oaProgression() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'oa_progression', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $oa_progression_page_query_execute = $oa_progression_page_query->execute();
    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $article_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'article')
      ->condition('field_article_type', 'oa_progression', '=')
      ->sort('created', 'DESC');
    $article_query_execute = $article_query->execute();

    foreach ($article_query_execute as $article_query_execute_value) {
      $article_load = Node::load($article_query_execute_value);
      $article_details[$article_query_execute_value]['article_title'] = $article_load->getTitle();
      $article_details[$article_query_execute_value]['article_body'] = $article_load->get('body')->value;
      $article_image = explode('//', $article_load->get('field_article_image')->entity->uri->value);
      global $base_url;
      $article_details[$article_query_execute_value]['article_image_url'] = $base_url . '/sites/default/files/' . $article_image[1];

      $field_mobile_article_image = explode('//', $article_load->get('field_mobile_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_mobile_article_image_url'] = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];

      $field_tablet_article_image = explode('//', $article_load->get('field_tablet_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_tablet_article_image_url'] = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];

      $article_details[$article_query_execute_value]['article_tid'] = $base_url . '/node/' . $article_query_execute_value;
      $link_external = $article_load->get('field_external_link')->value;

      $pdf_link_get_target_id = $article_load->get('field_pdf')->target_id;
      if (!empty($pdf_link_get_target_id)) {

        // Load file.
        $pdf_link_get_target_id_file = File::load($pdf_link_get_target_id);
        // Get origin image URI.
        $pdf_uri = $pdf_link_get_target_id_file->getFileUri();

        $pdf_link_get = explode('//', $pdf_uri);

        global $base_url;

        $pdf_link = $base_url . '/sites/default/files/' . $pdf_link_get[1];
      }
      if (!empty($link_external)) {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $link_external;
      }
      else {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $pdf_link;
      }

      $field_type = $article_load->get('field_type')->value;
      if (!empty($field_type)) {
        if ($field_type == 'link') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'view_slide') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link view-slide-link" target="_blank" href="' . $link_external . '">View</a>';
        }
        if ($field_type == 'pdf') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link pdf-link" target="_blank" href="' . $pdf_link . '">PDF</a>';
        }
      }

    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'oaprogression',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#article_details' => $article_details,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for congress hub page.
   */
  public function congressHub() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();

    $congree_hub_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'congress_hub', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $congree_hub_page_query_execute = $congree_hub_page_query->execute();
    foreach ($congree_hub_page_query_execute as $congress_hub_page_nids) {
      $entity_load = Node::load($congress_hub_page_nids);
      $body_value = $entity_load->get('body')->value;
      $node_title = $entity_load->getTitle();
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $journal_year_page_query = \Drupal::entityQuery('taxonomy_term')
      ->condition('status', 1, '=')
      ->condition('vid', 'journal_year')
      ->condition('langcode', $lang_code, '=')
      ->sort('name', 'DESC');
    $journal_year_page_query_execute = $journal_year_page_query->execute();

    foreach ($journal_year_page_query_execute as $journal_year_page_nids) {

      $current_path = \Drupal::service('path.current')->getPath();
      $path_args = explode('/', $current_path);
      $termname_year = $path_args[2];
      $year_term = Term::load($journal_year_page_nids);
      global $base_url;
      // $year_details[$journal_year_page_nids]['year_url'] = $base_url.'/congress-hub/'.$year_term->getName();
      // $year_details[$journal_year_page_nids]['year_name'] = $year_term->getName();
      if ($termname_year == $year_term->getName()) {
        $year_details[$journal_year_page_nids]['year_name_active_or_not'] = '<li class="active">
							<a href="' . $base_url . '/congress-hub/' . $year_term->getName() . '" data-drupal-link-system-path="<front>">' . $year_term->getName() . '</a>
						</li>';
      }
      else {
        $year_details[$journal_year_page_nids]['year_name_active_or_not'] = '<li class="">
							<a href="' . $base_url . '/congress-hub/' . $year_term->getName() . '" data-drupal-link-system-path="<front>">' . $year_term->getName() . '</a>
						</li>';
      }
    }

    // Echo '<pre>';print_r($year_details);exit;
    $journal_category_page_query = \Drupal::entityQuery('taxonomy_term')
      ->condition('status', 1, '=')
      ->condition('vid', 'journal_category')
      ->condition('field_category', 'congress_article', '=')
      ->sort('field_event_date', 'DESC');
    // ->sort('name', 'ASC');.
    $journal_category_page_query_execute = $journal_category_page_query->execute();
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);

    foreach ($journal_category_page_query_execute as $journal_category_page_nids) {

      $category_term = Term::load($journal_category_page_nids);
      $category_year_val = $category_term->get('field_journal_year')->first()->getValue()['target_id'];
      $category_year_val_load = Term::load($category_year_val);
      $category_name_val = $category_year_val_load->getName();
      if ($category_name_val == $path_args[2]) {
        $category_details[$journal_category_page_nids]['category_name'] = $category_term->getName();
        $category_details[$journal_category_page_nids]['category_description'] = $category_term->get('field_journal_description')->value;
        $category_details[$journal_category_page_nids]['category_tid'] = $base_url . '/articles/' . $journal_category_page_nids . '/' . $category_name_val;
        $category_details[$journal_category_page_nids]['term_tid'] = $journal_category_page_nids;

        $congree_hub_articles_page_query = \Drupal::entityQuery('node')
          ->condition('status', 1, '=')
          ->condition('type', 'congree_hub_articles')
          ->condition('field_journal_category', $journal_category_page_nids, '=')
          ->condition('field_article_type_co', 'congress_article', '=')
          ->sort('created', 'DESC');
        $congree_hub_articles_page_query_execute = $congree_hub_articles_page_query->execute();
        if (empty($congree_hub_articles_page_query_execute)) {
          $category_details[$journal_category_page_nids]['class_arrow'] = '';
        }
        else {
          $category_details[$journal_category_page_nids]['class_arrow'] = 'chub-read-link';
        }
      }

    }

    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $year_category = $path_args[2];
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'congresshub',
      '#year_details' => $year_details,
      '#category_details' => $category_details,
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#node_title' => $node_title,
      '#year_category' => $year_category,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for congress hub articles.
   */
  public function congressHubArticles() {
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $journal_category = $path_args[2];
    $year_category = $path_args[3];
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();

    if (!empty($journal_category)) {
      $congree_hub_articles_page_query = \Drupal::entityQuery('node')
        ->condition('status', 1, '=')
        ->condition('type', 'congree_hub_articles')
        ->condition('field_journal_category', $journal_category, '=')
        ->condition('field_article_type_co', 'congress_article', '=')
        ->condition('langcode', $lang_code, '=')
        ->sort('created', 'DESC');
      $congree_hub_articles_page_query_execute = $congree_hub_articles_page_query->execute();
      foreach ($congree_hub_articles_page_query_execute as $articles_value) {

        $entity_load = Node::load($articles_value);
        $article_data[$articles_value]['body_value'] = $entity_load->get('body')->value;
        $article_data[$articles_value]['node_title'] = substr($entity_load->getTitle(), 0, 100);
        $article_data[$articles_value]['author'] = substr($entity_load->get('field_author')->value, 0, 55);
        global $base_url;
        $article_data[$articles_value]['congresshub_nid'] = $base_url . '/node/' . $articles_value;
      }
    }
    else {
      $article_data = 'No Articles';
    }

    if (!empty($journal_category)) {
      $category_term = Term::load($journal_category);
      $category_name_val = $category_term->getName();
      $category_description_val = $category_term->get('field_details_description')->value;
      $journal_year_page_query = \Drupal::entityQuery('taxonomy_term')
        ->condition('status', 1, '=')
        ->condition('vid', 'journal_year')
        ->condition('langcode', $lang_code, '=')
        ->sort('name', 'DESC');
      $journal_year_page_query_execute = $journal_year_page_query->execute();

      foreach ($journal_year_page_query_execute as $journal_year_page_nids) {

        $current_path = \Drupal::service('path.current')->getPath();
        $path_args = explode('/', $current_path);
        $termname_year = $path_args[2];
        $get_year = $path_args[3];

        $year_term = Term::load($journal_year_page_nids);
        global $base_url;

        if ($get_year == $year_term->getName()) {
          $year_details[$journal_year_page_nids]['year_name_active_or_not'] = '<li class="active">
								<a href="' . $base_url . '/congress-hub/' . $year_term->getName() . '" data-drupal-link-system-path="<front>">' . $year_term->getName() . '</a>
							</li>';
        }
        else {
          $year_details[$journal_year_page_nids]['year_name_active_or_not'] = '<li class="">
								<a href="' . $base_url . '/congress-hub/' . $year_term->getName() . '" data-drupal-link-system-path="<front>">' . $year_term->getName() . '</a>
							</li>';
        }

      }
    }
    $current_path = \Drupal::service('path.current')->getPath();
    $path_args = explode('/', $current_path);
    $year_category = $path_args[3];
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'congresshubarticles',
      '#year_details' => $year_details,
      '#article_data' => $article_data,
      '#category_name_val' => $category_name_val,
      '#category_description_val' => $category_description_val,
      '#year_category' => $year_category,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
    ];

  }

  /**
   * Custom template for congress hub articles.
   */
  public function publicationCorner() {

    // Echo '<pre>';
    // exit;.
    $database = \Drupal::database();
    $publication_corner_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'publication_corner', '=')
      ->sort('created', 'DESC');
    $publication_corner_page_query_execute = $publication_corner_page_query->execute();
    foreach ($publication_corner_page_query_execute as $publication_corner_page_nids) {
      $entity_load = Node::load($publication_corner_page_nids);
      $body_value = $entity_load->get('body')->value;
      $node_title = $entity_load->getTitle();
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $pfizerpublicationcornerform = \Drupal::formBuilder()->getForm('\Drupal\pfizer_custom_pages\Form\PfizerPublicationCornerForm');

    $pfizerpublicationcornerajaxform = \Drupal::formBuilder()->getForm('\Drupal\pfizer_custom_pages\Form\PfizerPublicationCornerAjaxForm');
    $keyword = base64_decode(\Drupal::request()->get('keyword'));
    $author = base64_decode(\Drupal::request()->get('author'));
    $journal = base64_decode(\Drupal::request()->get('journal'));
    $year = base64_decode(\Drupal::request()->get('year'));
    $publication_type = base64_decode(\Drupal::request()->get('publication_type'));
    $article_type = base64_decode(\Drupal::request()->get('article_type'));
    $publication_congress = base64_decode(\Drupal::request()->get('congress_type'));

    // $publication_type_ajax = $_POST['ajaxPrimaryManuscript'];.
    $congree_hub_articles_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'congree_hub_articles');

    $publication_journal_array_count = count(explode(',', $journal));

    if ($publication_journal_array_count > 1) {
      $publication_journal_aa = explode(',', $journal);
      $congree_hub_articles_page_query->condition('field_journal_category', $publication_journal_aa, 'IN');
    }

    if ($publication_journal_array_count == 1) {
      if (!empty($journal) || $journal != 0) {
        $congree_hub_articles_page_query->condition('field_journal_category', $journal, '=');
      }
    }

    $publication_congress_type_array_count = count(explode(',', $publication_congress));
    if ($publication_congress_type_array_count > 1) {
      $publication_congress_type_aa = explode(',', $publication_congress);
      $congree_hub_articles_page_query->condition('field_journal_category', $publication_congress_type_aa, 'IN');
    }

    if ($publication_congress_type_array_count == 1) {
      if (!empty($publication_congress) || $publication_congress != 0) {
        $congree_hub_articles_page_query->condition('field_journal_category', $publication_congress, '=');
      }
    }

    // If (!empty($publication_congress) || $publication_congress != 0) {
    // $congree_hub_articles_page_query->condition('field_journal_category', $publication_congress, '=');
    // }.
    if (!empty($keyword)) {
      $congree_hub_articles_page_query->condition('title', '%' . $keyword . '%', 'LIKE');
    }

    if (!empty($author)) {
      $congree_hub_articles_page_query->condition('field_author', '%' . $author . '%', 'LIKE');
    }

    $publication_year_array_count = count(explode(',', $year));

    if ($publication_year_array_count > 1) {
      $publication_year_aa = explode(',', $year);
      $congree_hub_articles_page_query->condition('field_journal_year', $publication_year_aa, 'IN');
    }

    if ($publication_year_array_count == 1) {
      if (!empty($year) || $year != 0) {
        $congree_hub_articles_page_query->condition('field_journal_year', $year, '=');
      }
    }

    $publication_type_array_count = count(explode(',', $publication_type));

    if ($publication_type_array_count > 1) {
      $publication_type_aa = explode(',', $publication_type);
      $congree_hub_articles_page_query->condition('field_publication_type', $publication_type_aa, 'IN');
    }

    if ($publication_type_array_count == 1) {
      if (!empty($publication_type) || $publication_type != 0 || $publication_type != '') {
        $congree_hub_articles_page_query->condition('field_publication_type', $publication_type, '=');
      }
    }

    if (!empty($article_type) || $article_type != 0) {
      $congree_hub_articles_page_query->condition('field_article_type_co', $article_type, '=');
    }

    // $view_per_page = \Drupal::request()->get('pages_view');
    // $view_per_page = '10';
    // if (!empty($view_per_page)) {
    // $congree_hub_articles_page_query->range(0, $view_per_page);
    // }.
    $congree_hub_articles_page_query->sort('field_journal_year', 'DESC');

    $congree_hub_articles_page_query_execute = $congree_hub_articles_page_query->execute();

    foreach ($congree_hub_articles_page_query_execute as $congree_hub_articles_value) {

      $congress_node_load = Node::load($congree_hub_articles_value);

      $congress_details[$congree_hub_articles_value]['congress_title'] = $congress_node_load->getTitle();
      $congress_details[$congree_hub_articles_value]['congress_author'] = $congress_node_load->get('field_author')->value;

      $congress_details[$congree_hub_articles_value]['field_publication_type'] = str_replace('_', ' ', $congress_node_load->get('field_publication_type')->value);

      // $explode_category = explode('_', $congress_node_load->get('field_article_type_co')->value);
      // $congress_details[$congree_hub_articles_value]['field_target'] = $explode_category[0];.
      $field_category_term = $congress_node_load->field_journal_category[0]->target_id;

      $field_category_term_load = Term::load($field_category_term);

      // $congress_node_load->get('field_journal_category')->value;.
      $congress_details[$congree_hub_articles_value]['field_target'] = $field_category_term_load->getName();

      $date_published_congress = $congress_node_load->field_date_published->date;

      if (!empty($date_published_congress)) {
        $congress_details[$congree_hub_articles_value]['field_date_published'] = $congress_node_load->field_date_published->date->format('d F Y');
      }
      else {
        $congress_details[$congree_hub_articles_value]['field_date_published'] = '';
      }

      $journal_link = $congress_node_load->get('field_journal_link')->value;
      if (!empty($journal_link)) {

        $congress_details[$congree_hub_articles_value]['node_link'] = $congress_node_load->get('field_journal_link')->value;

      }
      else {

        global $base_url;

        $congress_details[$congree_hub_articles_value]['node_link'] = $base_url . '/node/' . $congree_hub_articles_value;
      }

      $congress_details[$congree_hub_articles_value]['node_id'] = $congree_hub_articles_value;

    }

    if (!empty($congress_details)) {
      $congress_details_array_count = count($congress_details);
      $congress_details = $congress_details;
    }
    else {
      $congress_details_array_count = 0;
      $congress_details = 0;
    }

    if (!empty($congress_details)) {

      $currentUser_id = \Drupal::currentUser()->id();

      foreach ($congress_details as $congress_details_value) {

        $nid_store = $congress_details_value['node_id'];
        $conn = Database::getConnection();
        $query_frequent_search = $conn->query("SELECT * FROM {frequent_search} where uid = $currentUser_id and nid = $nid_store");
        $result_frequent_search_val = $query_frequent_search->fetchAll();
        $date = date('Y-m-d H:i:s');
        if (empty($result_frequent_search_val)) {
          \Drupal::database()->insert('frequent_search')
            ->fields([
              'uid',
              'nid',
              'date',
            ])
            ->values([
              $currentUser_id,
              $nid_store,
              $date,
            ])
            ->execute();
        }
        else {
          $date = date('Y-m-d H:i:s');
          $conn = Database::getConnection();
          $conn->query("UPDATE {frequent_search} SET date = '$date' WHERE uid = $currentUser_id AND nid = $nid_store");
        }
      }
    }

    $pages_view = \Drupal::request()->get('pages_view');
    if ($pages_view == '' || empty($pages_view)) {
      $pages_view = '10';
    }
    else {
      $pages_view = \Drupal::request()->get('pages_view');
    }
    $per_page = $pages_view;
    if (count($congress_details) > 0) {
      $current_page = pager_default_initialize(count($congress_details), $per_page);
      $congress_details_data = array_chunk($congress_details, $per_page, TRUE);

    }

    // Else {
    // $current_page = 0;
    // $congress_details_data[$current_page] = [];
    // }.
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    $render[] = [
      '#theme' => 'publicationcorner',
      '#type' => 'remote',
      '#congress_details_data' => $congress_details_data[$current_page],
      '#page' => $current_page,
      '#pfizerpublicationcornerform' => $pfizerpublicationcornerform,
      '#congress_details' => $congress_details,
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#node_title' => $node_title,
      '#congress_details_array_count' => $congress_details_array_count,
      '#pfizerpublicationcornerajaxform' => $pfizerpublicationcornerajaxform,
      '#keyword' => $keyword,
      '#author' => $author,
      '#journal' => $journal,
      '#year' => $year,
      '#publication_type' => $publication_type,
      '#article_type' => $article_type,
      '#publication_congress' => $publication_congress,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
      '#pages_view' => $pages_view,
    ];

    $render[] = ['#type' => 'pager'];

    return $render;
  }

  /**
   * Custom template for congress hub articles.
   */
  public function frequentlySearched() {

    $database = \Drupal::database();
    $publication_corner_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'frequent_search', '=')
      ->sort('created', 'DESC');
    $publication_corner_page_query_execute = $publication_corner_page_query->execute();
    foreach ($publication_corner_page_query_execute as $publication_corner_page_nids) {
      $entity_load = Node::load($publication_corner_page_nids);
      $body_value = $entity_load->get('body')->value;
      $node_title = $entity_load->getTitle();
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $currentUser_id = \Drupal::currentUser()->id();
    $conn = Database::getConnection();

    // \Drupal::request()->get('pages_view');
    $view_per_page = '10';

    // If (!empty($view_per_page)) {.
    $query_frequent_search = $conn->query("SELECT * FROM {frequent_search} where uid = $currentUser_id ORDER BY date DESC LIMIT " . $view_per_page . ";");
    // // }
    // else {
    // $query_frequent_search = $conn->query("SELECT * FROM {frequent_search} where uid = $currentUser_id ORDER BY date DESC;");
    // }.
    $result_frequent_search_val = $query_frequent_search->fetchAll();
    foreach ($result_frequent_search_val as $result_frequent_search_value) {

      $nid_get = $result_frequent_search_value->nid;

      $frequently_searched_node_load = Node::load($nid_get);

      if (!empty($frequently_searched_node_load)) {
        $frequently_searched[$nid_get]['congress_title'] = $frequently_searched_node_load->getTitle();

        $frequently_searched[$nid_get]['congress_author'] = $frequently_searched_node_load->get('field_author')->value;

        $frequently_searched[$nid_get]['field_publication_type'] = str_replace('_', ' ', $frequently_searched_node_load->get('field_publication_type')->value);

        // $frequently_searched[$nid_get]['field_target'] = $frequently_searched_node_load->get('field_target')->value;
        // $explode_category = explode('_', $frequently_searched_node_load->get('field_article_type_co')->value);.
        // $frequently_searched[$nid_get]['field_target'] = $explode_category[0];.
        $field_category_term = $frequently_searched_node_load->field_journal_category[0]->target_id;

        $field_category_term_load = Term::load($field_category_term);

        // $congress_node_load->get('field_journal_category')->value;.
        $frequently_searched[$nid_get]['field_target'] = $field_category_term_load->getName();

        // $frequently_searched[$nid_get]['field_date_published'] = $frequently_searched_node_load->field_date_published->date->format('d F Y');.
        $date_published_congress = $frequently_searched_node_load->field_date_published->date;

        if (!empty($date_published_congress)) {
          $frequently_searched[$nid_get]['field_date_published'] = $frequently_searched_node_load->field_date_published->date->format('d F Y');
        }
        else {
          $frequently_searched[$nid_get]['field_date_published'] = '';
        }

        // Global $base_url;
        // $frequently_searched[$nid_get]['node_link'] = $base_url . '/node/' . $nid_get;.
        $journal_link = $frequently_searched_node_load->get('field_journal_link')->value;
        if (!empty($journal_link)) {

          $frequently_searched[$nid_get]['node_link'] = $frequently_searched_node_load->get('field_journal_link')->value;

        }
        else {

          global $base_url;

          $frequently_searched[$nid_get]['node_link'] = $base_url . '/node/' . $nid_get;
        }

        $frequently_searched[$nid_get]['node_id'] = $frequently_searched_node_load;
      }
    }
    if (!empty($frequently_searched)) {
      $frequently_searched_array_count = count($frequently_searched);
      $frequently_searched = $frequently_searched;
    }
    else {
      $frequently_searched_array_count = 0;
      $frequently_searched = "No record found.";
    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'frequentlysearched',
      '#frequently_searched' => $frequently_searched,
      '#frequently_searched_array_count' => $frequently_searched_array_count,
      '#body_value' => $body_value,
      '#node_title' => $node_title,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
    ];

  }

  /**
   * Custom template for oa progression page.
   */
  public function oaoverviewandunmetneed() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'oa_overview_unmet_need', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $oa_progression_page_query_execute = $oa_progression_page_query->execute();
    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $article_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'article')
      ->condition('field_article_type', 'oa_overview_unmet_need', '=')
      ->sort('created', 'DESC');
    $article_query_execute = $article_query->execute();

    foreach ($article_query_execute as $article_query_execute_value) {
      $article_load = Node::load($article_query_execute_value);
      $article_details[$article_query_execute_value]['article_title'] = $article_load->getTitle();
      $article_details[$article_query_execute_value]['article_body'] = $article_load->get('body')->value;
      $article_image = explode('//', $article_load->get('field_article_image')->entity->uri->value);
      global $base_url;
      $article_details[$article_query_execute_value]['article_image_url'] = $base_url . '/sites/default/files/' . $article_image[1];

      $field_mobile_article_image = explode('//', $article_load->get('field_mobile_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_mobile_article_image_url'] = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];

      $field_tablet_article_image = explode('//', $article_load->get('field_tablet_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_tablet_article_image_url'] = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];

      $article_details[$article_query_execute_value]['article_tid'] = $base_url . '/node/' . $article_query_execute_value;

      $link_external = $article_load->get('field_external_link')->value;

      $pdf_link_get_target_id = $article_load->get('field_pdf')->target_id;

      if (!empty($pdf_link_get_target_id)) {

        // Load file.
        $pdf_link_get_target_id_file = File::load($pdf_link_get_target_id);
        // Get origin image URI.
        $pdf_uri = $pdf_link_get_target_id_file->getFileUri();

        $pdf_link_get = explode('//', $pdf_uri);

        global $base_url;

        $pdf_link = $base_url . '/sites/default/files/' . $pdf_link_get[1];

      }
      if (!empty($link_external)) {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $link_external;
      }
      else {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $pdf_link;
      }

      $field_type = $article_load->get('field_type')->value;
      if (!empty($field_type)) {
        if ($field_type == 'link') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'view_slide') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link view-slide-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'pdf') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link pdf-link" target="_blank" href="' . $pdf_link . '"></a>';
        }
      }
    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'oaoverviewandunmetneed',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#article_details' => $article_details,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for oa progression page.
   */
  public function painttheoapicture() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'paint_the_oa_picture', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $oa_progression_page_query_execute = $oa_progression_page_query->execute();
    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $article_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'article')
      ->condition('field_article_type', 'paint_the_oa_picture', '=')
      ->sort('field_weight', 'ASC');
    $article_query_execute = $article_query->execute();

    foreach ($article_query_execute as $article_query_execute_value) {
      $article_load = Node::load($article_query_execute_value);
      $article_details[$article_query_execute_value]['article_title'] = $article_load->getTitle();
      $article_details[$article_query_execute_value]['article_body'] = $article_load->get('body')->value;
      $article_image = explode('//', $article_load->get('field_article_image')->entity->uri->value);
      global $base_url;
      $article_details[$article_query_execute_value]['article_image_url'] = $base_url . '/sites/default/files/' . $article_image[1];

      $article_details[$article_query_execute_value]['article_tid'] = $base_url . '/node/' . $article_query_execute_value;

      $field_mobile_article_image = explode('//', $article_load->get('field_mobile_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_mobile_article_image_url'] = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];

      $field_tablet_article_image = explode('//', $article_load->get('field_tablet_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_tablet_article_image_url'] = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];

      $link_external = $article_load->get('field_external_link')->value;

      $pdf_link_get_target_id = $article_load->get('field_pdf')->target_id;
      if (!empty($pdf_link_get_target_id)) {

        // Load file.
        $pdf_link_get_target_id_file = File::load($pdf_link_get_target_id);
        // Get origin image URI.
        $pdf_uri = $pdf_link_get_target_id_file->getFileUri();

        $pdf_link_get = explode('//', $pdf_uri);

        global $base_url;

        $pdf_link = $base_url . '/sites/default/files/' . $pdf_link_get[1];
      }
      if (!empty($link_external)) {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $link_external;
      }
      else {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $pdf_link;
      }

      $field_type = $article_load->get('field_type')->value;
      if (!empty($field_type)) {
        if ($field_type == 'link') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'view_slide') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link view-slide-link" target="_blank" href="' . $link_external . '">View</a>';
        }
        if ($field_type == 'pdf') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link pdf-link" target="_blank" href="' . $pdf_link . '">PDF</a>';
        }
      }
    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'painttheoapicture',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#article_details' => $article_details,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for oa partnerships and collaborations page.
   */
  public function partnershipsandcollaborations() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'partnerships_and_collaborations', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');

    $oa_progression_page_query_execute = $oa_progression_page_query->execute();

    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'partnershipsandcollaborations',
      '#body_value' => $body_value,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
    ];
  }

  /**
   * Custom template for OA DIAGNOSIS & MANAGEMENT page.
   */
  public function oadiagnosisandmanagement() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'oa_diagnosis_and_management', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $oa_progression_page_query_execute = $oa_progression_page_query->execute();
    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $article_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'article')
      ->condition('field_article_type', 'oa_diagnosis_and_management', '=')
      ->sort('created', 'DESC');
    $article_query_execute = $article_query->execute();

    foreach ($article_query_execute as $article_query_execute_value) {
      $article_load = Node::load($article_query_execute_value);
      $article_details[$article_query_execute_value]['article_title'] = $article_load->getTitle();
      $article_details[$article_query_execute_value]['article_body'] = $article_load->get('body')->value;
      $article_image = explode('//', $article_load->get('field_article_image')->entity->uri->value);
      global $base_url;
      $article_details[$article_query_execute_value]['article_image_url'] = $base_url . '/sites/default/files/' . $article_image[1];

      $field_mobile_article_image = explode('//', $article_load->get('field_mobile_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_mobile_article_image_url'] = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];

      $field_tablet_article_image = explode('//', $article_load->get('field_tablet_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_tablet_article_image_url'] = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];

      $article_details[$article_query_execute_value]['article_tid'] = $base_url . '/node/' . $article_query_execute_value;

      $link_external = $article_load->get('field_external_link')->value;

      $pdf_link_get_target_id = $article_load->get('field_pdf')->target_id;

      if (!empty($pdf_link_get_target_id)) {

        // Load file.
        $pdf_link_get_target_id_file = File::load($pdf_link_get_target_id);
        // Get origin image URI.
        $pdf_uri = $pdf_link_get_target_id_file->getFileUri();

        $pdf_link_get = explode('//', $pdf_uri);

        global $base_url;

        $pdf_link = $base_url . '/sites/default/files/' . $pdf_link_get[1];

      }
      if (!empty($link_external)) {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $link_external;
      }
      else {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $pdf_link;
      }

      $field_type = $article_load->get('field_type')->value;
      if (!empty($field_type)) {
        if ($field_type == 'link') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'view_slide') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link view-slide-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'pdf') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link pdf-link" target="_blank" href="' . $pdf_link . '"></a>';
        }
      }
    }

    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'oadiagnosisandmanagement',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#article_details' => $article_details,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

  /**
   * Custom template for OTHER RESOURCES page.
   */
  public function otherresources() {
    $database = \Drupal::database();
    $lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $oa_progression_page_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'master_pages')
      ->condition('field_select_page_type', 'other_resources', '=')
      ->condition('langcode', $lang_code, '=')
      ->sort('created', 'DESC');
    $oa_progression_page_query_execute = $oa_progression_page_query->execute();
    foreach ($oa_progression_page_query_execute as $oa_progression_page_nids) {
      $entity_load = Node::load($oa_progression_page_nids);
      $body_value = $entity_load->get('body')->value;
      $image_url_get = explode('//', $entity_load->get('field_image')->entity->uri->value);
      $field_mobile_article_image = explode('//', $entity_load->get('field_mobile_article_image')->entity->uri->value);
      $field_tablet_article_image = explode('//', $entity_load->get('field_tablet_article_image')->entity->uri->value);
      global $base_url;
      $image_url = $base_url . '/sites/default/files/' . $image_url_get[1];
      $field_mobile_article_image_url = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];
      $field_tablet_article_image_url = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];
    }

    $article_query = \Drupal::entityQuery('node')
      ->condition('status', 1, '=')
      ->condition('type', 'article')
      ->condition('field_article_type', 'other_resources', '=')
      ->sort('created', 'DESC');
    $article_query_execute = $article_query->execute();

    foreach ($article_query_execute as $article_query_execute_value) {
      $article_load = Node::load($article_query_execute_value);
      $article_details[$article_query_execute_value]['article_title'] = $article_load->getTitle();
      $article_details[$article_query_execute_value]['article_body'] = $article_load->get('body')->value;
      $article_image = explode('//', $article_load->get('field_article_image')->entity->uri->value);
      global $base_url;
      $article_details[$article_query_execute_value]['article_image_url'] = $base_url . '/sites/default/files/' . $article_image[1];

      $field_mobile_article_image = explode('//', $article_load->get('field_mobile_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_mobile_article_image_url'] = $base_url . '/sites/default/files/' . $field_mobile_article_image[1];

      $field_tablet_article_image = explode('//', $article_load->get('field_tablet_article_image')->entity->uri->value);
      $article_details[$article_query_execute_value]['field_tablet_article_image_url'] = $base_url . '/sites/default/files/' . $field_tablet_article_image[1];

      $article_details[$article_query_execute_value]['article_tid'] = $base_url . '/node/' . $article_query_execute_value;

      $link_external = $article_load->get('field_external_link')->value;

      $pdf_link_get_target_id = $article_load->get('field_pdf')->target_id;

      if (!empty($pdf_link_get_target_id)) {

        // Load file.
        $pdf_link_get_target_id_file = File::load($pdf_link_get_target_id);
        // Get origin image URI.
        $pdf_uri = $pdf_link_get_target_id_file->getFileUri();

        $pdf_link_get = explode('//', $pdf_uri);

        global $base_url;

        $pdf_link = $base_url . '/sites/default/files/' . $pdf_link_get[1];

      }
      if (!empty($link_external)) {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $link_external;
      }
      else {
        $article_details[$article_query_execute_value]['article_pdf_link'] = $pdf_link;
      }

      $field_type = $article_load->get('field_type')->value;
      if (!empty($field_type)) {
        if ($field_type == 'link') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'view_slide') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link view-slide-link" target="_blank" href="' . $link_external . '"></a>';
        }
        if ($field_type == 'pdf') {
          $article_details[$article_query_execute_value]['field_type'] = '<a class="ext-link pdf-link" target="_blank" href="' . $pdf_link . '"></a>';
        }
      }
    }
    $megamenu_config = \Drupal::config('custom_menu_dashboard.settings');
    $megamenu_config_get = $megamenu_config->get('megamenuhtml');
    $mobilemenu_config_get = $megamenu_config->get('mobilemegamenuhtml');
    return [
      '#theme' => 'otherresources',
      '#body_value' => $body_value,
      '#image_url' => $image_url,
      '#article_details' => $article_details,
      '#megamenu_config_get' => $megamenu_config_get,
      '#mobilemenu_config_get' => $mobilemenu_config_get,
      '#field_mobile_article_image' => $field_mobile_article_image_url,
      '#field_tablet_article_image_url' => $field_tablet_article_image_url,
    ];

  }

}
